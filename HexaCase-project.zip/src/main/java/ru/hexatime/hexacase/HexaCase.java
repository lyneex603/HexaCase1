package ru.hexatime.hexacase;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.JoinConfiguration;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.type.Chest;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Display;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;

public class HexaCase extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    // Большой сундук = 54 слота
    private static final int MENU_SIZE = 54;
    private static final int[] CRATE_SLOTS = {19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
    private static final int EMPTY_SLOT = 22;
    private static final int HISTORY_SLOT = 49;
    private static final int BACK_SLOT = 49;
    private static final int HISTORY_SHOWN = 45;
    private static final String SEP = "|||";

    private static final String KIND_MAIN = "main";
    private static final String KIND_HISTORY = "history";

    private final Map<String, Crate> crates = new LinkedHashMap<>();
    private final Map<UUID, Session> sessions = new HashMap<>();
    private final Map<String, Session> activeBlocks = new HashMap<>();
    private final Set<String> menuBlocks = new HashSet<>();
    private final Random random = new Random();
    private final Map<UUID, Map<String, Holo>> holos = new HashMap<>();

    private File dataFile;
    private YamlConfiguration data;
    private BukkitTask holoTask;

    // ------------------------------------------------------------------ классы данных

    static final class Crate {
        String id;
        String name;
        Material icon;
        int chests;
        List<Reward> rewards = new ArrayList<>();
    }

    static final class Reward {
        String name;
        double weight;
        Material material;
        int amount;
        List<String> commands = new ArrayList<>();
        String skipPerm = "";
        List<String> fallback = new ArrayList<>();
    }

    static final class Session {
        Player player;
        Crate crate;
        Block origin;
        boolean chosen;
        boolean done;
        int left;
        BossBar bar;
        BukkitTask timer;
        List<Block> blocks = new ArrayList<>();
        List<BlockState> originals = new ArrayList<>();
        List<Reward> rolls = new ArrayList<>();
        List<ArmorStand> stands = new ArrayList<>();
    }

    static final class MenuHolder implements InventoryHolder {
        Inventory inv;
        final String kind;
        final Block origin;
        final Map<Integer, String> slots = new HashMap<>();

        MenuHolder(String kind, Block origin) {
            this.kind = kind;
            this.origin = origin;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    static final class Holo {
        TextDisplay td;
        int shown = -1;
    }

    // ------------------------------------------------------------------ жизненный цикл

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        menuBlocks.addAll(data.getStringList("blocks"));
        loadCrates();
        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("case") != null) {
            getCommand("case").setExecutor(this);
            getCommand("case").setTabCompleter(this);
        }
        holoTask = new BukkitRunnable() {
            @Override
            public void run() {
                tickHolograms();
            }
        }.runTaskTimer(this, 20L, 20L);
        getLogger().info("HexaCase загружен, кейсов: " + crates.size());
    }

    @Override
    public void onDisable() {
        if (holoTask != null) {
            holoTask.cancel();
        }
        for (Session s : new ArrayList<>(sessions.values())) {
            finish(s, random.nextInt(s.blocks.size()));
        }
        removeAllHolos();
    }

    private void loadCrates() {
        crates.clear();
        ConfigurationSection sec = getConfig().getConfigurationSection("crates");
        if (sec == null) {
            return;
        }
        for (String key : sec.getKeys(false)) {
            ConfigurationSection cs = sec.getConfigurationSection(key);
            if (cs == null) {
                continue;
            }
            Crate c = new Crate();
            c.id = key.toLowerCase();
            c.name = cs.getString("name", key);
            Material icon = Material.matchMaterial(cs.getString("icon", "CHEST"));
            c.icon = icon != null ? icon : Material.CHEST;
            c.chests = Math.max(3, Math.min(10, cs.getInt("chests", 6)));
            ConfigurationSection rs = cs.getConfigurationSection("rewards");
            if (rs != null) {
                for (String rk : rs.getKeys(false)) {
                    ConfigurationSection r = rs.getConfigurationSection(rk);
                    if (r == null) {
                        continue;
                    }
                    Reward rw = new Reward();
                    rw.name = r.getString("name", rk);
                    rw.weight = r.getDouble("weight", 1);
                    String mat = r.getString("material");
                    if (mat != null) {
                        rw.material = Material.matchMaterial(mat);
                        if (rw.material == null) {
                            getLogger().warning("Неизвестный материал '" + mat + "' в награде " + key + "/" + rk);
                        }
                    }
                    rw.amount = r.getInt("amount", 1);
                    rw.commands = r.getStringList("commands");
                    rw.skipPerm = r.getString("skip-if-permission", "");
                    rw.fallback = r.getStringList("fallback-commands");
                    c.rewards.add(rw);
                }
            }
            crates.put(c.id, c);
        }
    }

    // ------------------------------------------------------------------ данные игроков

    private int getCount(UUID id, String crate) {
        return data.getInt("players." + id + "." + crate, 0);
    }

    private void addCount(UUID id, String crate, int delta) {
        int v = Math.max(0, getCount(id, crate) + delta);
        data.set("players." + id + "." + crate, v);
        saveData();
        Player p = Bukkit.getPlayer(id);
        if (p != null) {
            refreshHolograms(p);
        }
    }

    private int totalCount(UUID id) {
        int sum = 0;
        for (Crate c : crates.values()) {
            sum += getCount(id, c.id);
        }
        return sum;
    }

    private void saveData() {
        try {
            data.save(dataFile);
        } catch (IOException e) {
            getLogger().warning("Не удалось сохранить data.yml: " + e.getMessage());
        }
    }

    private void saveBlocks() {
        data.set("blocks", new ArrayList<>(menuBlocks));
        saveData();
    }

    // ------------------------------------------------------------------ история

    private void recordHistory(Player p, Crate crate, Reward reward, boolean compensated) {
        String name = reward.name + (compensated ? " &7(компенсация)" : "");
        String mat = reward.material != null ? reward.material.name() : "PAPER";
        String entry = System.currentTimeMillis() + SEP + crate.id + SEP + name + SEP + mat;
        String path = "history." + p.getUniqueId();
        List<String> list = new ArrayList<>(data.getStringList(path));
        list.add(0, entry);
        int limit = Math.max(10, getConfig().getInt("history-limit", 100));
        while (list.size() > limit) {
            list.remove(list.size() - 1);
        }
        data.set(path, list);
        saveData();
    }

    private String fmtTime(long ts) {
        ZoneId zone;
        try {
            zone = ZoneId.of(getConfig().getString("timezone", "Europe/Moscow"));
        } catch (Exception e) {
            zone = ZoneId.systemDefault();
        }
        return DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm").withZone(zone).format(Instant.ofEpochMilli(ts));
    }

    private String[] parseEntry(String raw) {
        String[] parts = raw.split(Pattern.quote(SEP), -1);
        if (parts.length < 4) {
            return null;
        }
        return parts;
    }

    // ------------------------------------------------------------------ утилиты

    private static Component txt(String s) {
        return LEGACY.deserialize(s);
    }

    private static Component item(String s) {
        return LEGACY.deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    private static String key(Block b) {
        return b.getWorld().getName() + ";" + b.getX() + ";" + b.getY() + ";" + b.getZ();
    }

    private boolean isProtected(Block b) {
        String k = key(b);
        return activeBlocks.containsKey(k) || menuBlocks.contains(k);
    }

    private int indexOfBlock(Session s, Block b) {
        String k = key(b);
        for (int i = 0; i < s.blocks.size(); i++) {
            if (key(s.blocks.get(i)).equals(k)) {
                return i;
            }
        }
        return -1;
    }

    private ItemStack named(Material m, String name, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.displayName(item(name));
            if (lore != null && !lore.isEmpty()) {
                List<Component> l = new ArrayList<>();
                for (String s : lore) {
                    l.add(item(s));
                }
                meta.lore(l);
            }
            it.setItemMeta(meta);
        }
        return it;
    }

    // ------------------------------------------------------------------ голограмма над блоком

    private List<String> hologramLines() {
        List<String> lines = getConfig().getStringList("hologram.lines");
        if (lines.isEmpty()) {
            lines = List.of("&6&lКейсы", "&eнажмите чтобы открыть", "&7Доступно: &f{count}");
        }
        return lines;
    }

    private Component hologramText(int total) {
        List<Component> parts = new ArrayList<>();
        for (String line : hologramLines()) {
            parts.add(txt(line.replace("{count}", String.valueOf(total))));
        }
        return Component.join(JoinConfiguration.newlines(), parts);
    }

    private void tickHolograms() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            refreshHolograms(p);
        }
        // чистим записи офлайн-игроков
        Iterator<UUID> it = holos.keySet().iterator();
        while (it.hasNext()) {
            UUID id = it.next();
            if (Bukkit.getPlayer(id) == null) {
                Map<String, Holo> m = holos.get(id);
                if (m != null) {
                    for (Holo h : m.values()) {
                        if (h.td != null) {
                            h.td.remove();
                        }
                    }
                }
                it.remove();
            }
        }
    }

    private void refreshHolograms(Player p) {
        Map<String, Holo> mine = holos.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>());

        // убираем надписи отвязанных блоков и мёртвые сущности
        Iterator<Map.Entry<String, Holo>> it = mine.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Holo> e = it.next();
            Holo h = e.getValue();
            if (!menuBlocks.contains(e.getKey()) || h.td == null || !h.td.isValid()) {
                if (h.td != null) {
                    h.td.remove();
                }
                it.remove();
            }
        }

        int total = totalCount(p.getUniqueId());
        double view = getConfig().getDouble("hologram.view-distance", 40);
        double height = getConfig().getDouble("hologram.height", 1.9);

        for (String k : menuBlocks) {
            String[] parts = k.split(";");
            if (parts.length < 4) {
                continue;
            }
            World w = Bukkit.getWorld(parts[0]);
            if (w == null) {
                continue;
            }
            int x;
            int y;
            int z;
            try {
                x = Integer.parseInt(parts[1]);
                y = Integer.parseInt(parts[2]);
                z = Integer.parseInt(parts[3]);
            } catch (NumberFormatException ex) {
                continue;
            }
            Location loc = new Location(w, x + 0.5, y + height, z + 0.5);
            Holo existing = mine.get(k);
            boolean near = p.getWorld().equals(w) && p.getLocation().distanceSquared(loc) <= view * view;
            if (!near || !w.isChunkLoaded(x >> 4, z >> 4)) {
                if (existing != null) {
                    if (existing.td != null) {
                        existing.td.remove();
                    }
                    mine.remove(k);
                }
                continue;
            }
            if (existing == null) {
                final Component text = hologramText(total);
                TextDisplay td = w.spawn(loc, TextDisplay.class, d -> {
                    d.setVisibleByDefault(false);
                    d.setPersistent(false);
                    d.setBillboard(Display.Billboard.CENTER);
                    d.text(text);
                });
                p.showEntity(this, td);
                Holo h = new Holo();
                h.td = td;
                h.shown = total;
                mine.put(k, h);
            } else if (existing.shown != total) {
                existing.td.text(hologramText(total));
                existing.shown = total;
            }
        }
    }

    private void removeHolos(UUID id) {
        Map<String, Holo> m = holos.remove(id);
        if (m == null) {
            return;
        }
        for (Holo h : m.values()) {
            if (h.td != null) {
                h.td.remove();
            }
        }
    }

    private void removeAllHolos() {
        for (UUID id : new ArrayList<>(holos.keySet())) {
            removeHolos(id);
        }
    }

    private void refreshAllHolograms() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            refreshHolograms(p);
        }
    }

    // ------------------------------------------------------------------ меню (большой сундук)

    private void openMenu(Player p, Block origin) {
        MenuHolder holder = new MenuHolder(KIND_MAIN, origin);
        holder.inv = Bukkit.createInventory(holder, MENU_SIZE, txt("&8Ваши кейсы"));

        ItemStack filler = named(Material.GRAY_STAINED_GLASS_PANE, " ", null);
        for (int i = 0; i < MENU_SIZE; i++) {
            holder.inv.setItem(i, filler);
        }

        int idx = 0;
        for (Crate c : crates.values()) {
            if (idx >= CRATE_SLOTS.length) {
                break;
            }
            int cnt = getCount(p.getUniqueId(), c.id);
            if (cnt <= 0) {
                continue;
            }
            int slot = CRATE_SLOTS[idx++];
            holder.inv.setItem(slot, named(c.icon, c.name,
                    List.of("&7У вас: &f" + cnt, "&eНажмите, чтобы открыть")));
            holder.slots.put(slot, c.id);
        }
        if (idx == 0) {
            holder.inv.setItem(EMPTY_SLOT, named(Material.BARRIER, "&cУ вас нет кейсов",
                    List.of("&7Кейсы можно получить в донате")));
        }

        int hist = data.getStringList("history." + p.getUniqueId()).size();
        holder.inv.setItem(HISTORY_SLOT, named(Material.BOOK, "&6История открытий",
                List.of("&7Записей: &f" + hist, "&eНажмите, чтобы посмотреть")));

        p.openInventory(holder.inv);
    }

    private void openHistory(Player p, Block origin) {
        MenuHolder holder = new MenuHolder(KIND_HISTORY, origin);
        holder.inv = Bukkit.createInventory(holder, MENU_SIZE, txt("&8История открытий"));

        List<String> list = data.getStringList("history." + p.getUniqueId());
        int shown = 0;
        for (String raw : list) {
            if (shown >= HISTORY_SHOWN) {
                break;
            }
            String[] e = parseEntry(raw);
            if (e == null) {
                continue;
            }
            long ts;
            try {
                ts = Long.parseLong(e[0]);
            } catch (NumberFormatException ex) {
                continue;
            }
            Crate c = crates.get(e[1]);
            String crateName = c != null ? c.name : e[1];
            Material m = Material.matchMaterial(e[3]);
            if (m == null || !m.isItem() || m.isAir()) {
                m = Material.PAPER;
            }
            holder.inv.setItem(shown, named(m, e[2],
                    List.of("&7Кейс: " + crateName, "&7Время: &f" + fmtTime(ts))));
            shown++;
        }
        if (shown == 0) {
            holder.inv.setItem(22, named(Material.BARRIER, "&cИстория пуста",
                    List.of("&7Вы ещё не открывали кейсы")));
        }
        holder.inv.setItem(BACK_SLOT, named(Material.ARROW, "&eНазад", null));

        p.openInventory(holder.inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof MenuHolder holder)) {
            return;
        }
        event.setCancelled(true);
        if (event.getClickedInventory() != top) {
            return;
        }
        if (!(event.getWhoClicked() instanceof Player p)) {
            return;
        }
        int slot = event.getSlot();

        if (holder.kind.equals(KIND_HISTORY)) {
            if (slot == BACK_SLOT) {
                Bukkit.getScheduler().runTask(this, () -> openMenu(p, holder.origin));
            }
            return;
        }

        if (slot == HISTORY_SLOT) {
            Bukkit.getScheduler().runTask(this, () -> openHistory(p, holder.origin));
            return;
        }

        String id = holder.slots.get(slot);
        if (id == null) {
            return;
        }
        Crate crate = crates.get(id);
        if (crate == null) {
            p.closeInventory();
            return;
        }
        p.closeInventory();
        startOpening(p, crate, holder.origin);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof MenuHolder) {
            event.setCancelled(true);
        }
    }

    // ------------------------------------------------------------------ открытие кейса

    private boolean isFree(Block b) {
        return b.getType().isAir()
                && b.getRelative(BlockFace.UP).getType().isAir()
                && b.getRelative(BlockFace.DOWN).getType().isSolid();
    }

    /** Ищет места для сундуков по кольцу вокруг БЛОКА кейсов (а не вокруг игрока). */
    private List<Block> findSpots(Block origin, int radius, int need) {
        World w = origin.getWorld();
        int cx = origin.getX();
        int cy = origin.getY();
        int cz = origin.getZ();
        List<Block> spots = new ArrayList<>();
        int[] dys = {0, 1, -1, 2, -2};
        for (int i = 0; i < need; i++) {
            double ang = 2 * Math.PI * i / need;
            int x = cx + (int) Math.round(Math.cos(ang) * radius);
            int z = cz + (int) Math.round(Math.sin(ang) * radius);
            for (int dy : dys) {
                Block b = w.getBlockAt(x, cy + dy, z);
                if (isFree(b) && !spots.contains(b) && !isProtected(b)) {
                    spots.add(b);
                    break;
                }
            }
        }
        return spots;
    }

    private Reward roll(Crate c) {
        double total = 0;
        for (Reward r : c.rewards) {
            total += Math.max(0, r.weight);
        }
        if (total <= 0) {
            return c.rewards.get(random.nextInt(c.rewards.size()));
        }
        double x = random.nextDouble() * total;
        for (Reward r : c.rewards) {
            x -= Math.max(0, r.weight);
            if (x < 0) {
                return r;
            }
        }
        return c.rewards.get(c.rewards.size() - 1);
    }

    private void startOpening(Player p, Crate crate, Block origin) {
        if (sessions.containsKey(p.getUniqueId())) {
            return;
        }
        if (crate.rewards.isEmpty()) {
            p.sendMessage(txt("&cВ этом кейсе нет наград."));
            return;
        }
        if (getCount(p.getUniqueId(), crate.id) <= 0) {
            p.sendMessage(txt("&cУ вас нет такого кейса."));
            return;
        }
        if (origin == null || !origin.getWorld().equals(p.getWorld())) {
            p.sendMessage(txt("&cПодойдите к блоку кейсов."));
            return;
        }

        int radius = Math.max(2, getConfig().getInt("ring-radius", 3));
        List<Block> spots = findSpots(origin, radius, crate.chests);
        if (spots.size() < crate.chests) {
            p.sendMessage(txt("&cРядом с блоком мало места. Освободите площадку вокруг него."));
            return;
        }

        addCount(p.getUniqueId(), crate.id, -1);

        Session s = new Session();
        s.player = p;
        s.crate = crate;
        s.origin = origin;

        for (Block b : spots) {
            s.originals.add(b.getState());
            Chest cd = (Chest) Material.CHEST.createBlockData();
            double dx = origin.getX() - b.getX();
            double dz = origin.getZ() - b.getZ();
            BlockFace face;
            if (Math.abs(dx) > Math.abs(dz)) {
                face = dx > 0 ? BlockFace.EAST : BlockFace.WEST;
            } else {
                face = dz > 0 ? BlockFace.SOUTH : BlockFace.NORTH;
            }
            cd.setFacing(face);
            cd.setType(Chest.Type.SINGLE);
            b.setBlockData(cd, false);
            s.blocks.add(b);
            s.rolls.add(roll(crate));
            activeBlocks.put(key(b), s);
        }

        int total = getConfig().getInt("timeout-seconds", 30);
        s.left = total;
        s.bar = Bukkit.createBossBar("Выберите сундук в течение " + total + " сек.", BarColor.GREEN, BarStyle.SOLID);
        s.bar.addPlayer(p);
        sessions.put(p.getUniqueId(), s);

        p.playSound(p.getLocation(), Sound.BLOCK_CHEST_OPEN, 1f, 1f);
        p.sendMessage(txt("&aВыберите один из сундуков — нажмите на него."));

        final int totalF = total;
        s.timer = new BukkitRunnable() {
            @Override
            public void run() {
                if (s.done || s.chosen) {
                    cancel();
                    return;
                }
                s.left--;
                if (s.left <= 0) {
                    pick(s, random.nextInt(s.blocks.size()));
                    cancel();
                    return;
                }
                s.bar.setTitle("Выберите сундук в течение " + s.left + " сек.");
                s.bar.setProgress(Math.max(0.0, Math.min(1.0, (double) s.left / (double) totalF)));
            }
        }.runTaskTimer(this, 20L, 20L);
    }

    private void pick(Session s, int index) {
        if (s.chosen || s.done || index < 0 || index >= s.blocks.size()) {
            return;
        }
        s.chosen = true;
        Reward r = s.rolls.get(index);
        award(s, r);

        Player p = s.player;
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        p.sendMessage(txt("&aВам выпало: &f" + r.name));
        if (s.bar != null) {
            s.bar.removeAll();
        }

        for (int i = 0; i < s.blocks.size(); i++) {
            String prefix = (i == index) ? "&a&l✔ &r" : "&7";
            s.stands.add(spawnLabel(s.blocks.get(i), prefix + s.rolls.get(i).name));
        }

        long ticks = getConfig().getInt("reveal-seconds", 6) * 20L;
        Bukkit.getScheduler().runTaskLater(this, () -> cleanup(s), ticks);
    }

    private ArmorStand spawnLabel(Block b, String text) {
        Location loc = b.getLocation().add(0.5, 0.9, 0.5);
        return b.getWorld().spawn(loc, ArmorStand.class, as -> {
            as.setVisible(false);
            as.setGravity(false);
            as.setMarker(true);
            as.setSmall(true);
            as.setInvulnerable(true);
            as.setPersistent(false);
            as.customName(txt(text));
            as.setCustomNameVisible(true);
        });
    }

    /** Завершение без показа остальных сундуков (выход игрока / выключение сервера). */
    private void finish(Session s, int index) {
        if (!s.chosen && !s.done) {
            s.chosen = true;
            award(s, s.rolls.get(index));
        }
        cleanup(s);
    }

    private void cleanup(Session s) {
        if (s.done) {
            return;
        }
        s.done = true;
        if (s.timer != null) {
            s.timer.cancel();
        }
        if (s.bar != null) {
            s.bar.removeAll();
        }
        for (ArmorStand as : s.stands) {
            as.remove();
        }
        for (Block b : s.blocks) {
            activeBlocks.remove(key(b));
        }
        for (BlockState st : s.originals) {
            st.update(true, false);
        }
        sessions.remove(s.player.getUniqueId());
    }

    private void award(Session s, Reward r) {
        boolean compensated = give(s.player, r);
        recordHistory(s.player, s.crate, r, compensated);
    }

    /** @return true, если выдана компенсация вместо награды */
    private boolean give(Player p, Reward r) {
        if (!r.skipPerm.isEmpty() && p.hasPermission(r.skipPerm)) {
            p.sendMessage(txt("&eЭта награда у вас уже есть (или выше), выдана компенсация."));
            runCommands(p, r.fallback);
            return true;
        }
        if (r.material != null) {
            ItemStack it = new ItemStack(r.material, Math.max(1, r.amount));
            Map<Integer, ItemStack> left = p.getInventory().addItem(it);
            for (ItemStack rest : left.values()) {
                p.getWorld().dropItemNaturally(p.getLocation(), rest);
            }
        }
        runCommands(p, r.commands);
        return false;
    }

    private void runCommands(Player p, List<String> cmds) {
        for (String c : cmds) {
            String cmd = c.replace("{player}", p.getName()).replace("{uuid}", p.getUniqueId().toString());
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        }
    }

    // ------------------------------------------------------------------ события мира

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        Block b = event.getClickedBlock();
        if (b == null) {
            return;
        }
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK && event.getAction() != Action.LEFT_CLICK_BLOCK) {
            return;
        }
        String k = key(b);
        Session s = activeBlocks.get(k);
        if (s != null) {
            event.setCancelled(true);
            if (event.getHand() == EquipmentSlot.OFF_HAND) {
                return;
            }
            if (s.player.equals(event.getPlayer()) && !s.chosen) {
                pick(s, indexOfBlock(s, b));
            }
            return;
        }
        if (menuBlocks.contains(k)) {
            event.setCancelled(true);
            if (event.getAction() == Action.RIGHT_CLICK_BLOCK && event.getHand() == EquipmentSlot.HAND) {
                openMenu(event.getPlayer(), b);
            }
        }
    }

    @EventHandler
    public void onBreak(BlockBreakEvent event) {
        if (isProtected(event.getBlock())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onExplode(EntityExplodeEvent event) {
        event.blockList().removeIf(this::isProtected);
    }

    @EventHandler
    public void onBlockExplode(BlockExplodeEvent event) {
        event.blockList().removeIf(this::isProtected);
    }

    @EventHandler
    public void onPistonExtend(BlockPistonExtendEvent event) {
        for (Block b : event.getBlocks()) {
            if (isProtected(b)) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onPistonRetract(BlockPistonRetractEvent event) {
        for (Block b : event.getBlocks()) {
            if (isProtected(b)) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Session s = sessions.get(event.getPlayer().getUniqueId());
        if (s != null) {
            finish(s, random.nextInt(s.blocks.size()));
        }
        removeHolos(event.getPlayer().getUniqueId());
    }

    // ------------------------------------------------------------------ команды

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("hexacase.admin")) {
            sender.sendMessage(txt("&cНет доступа."));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(txt("&e/case give <ник> <кейс> [число] &7| &e/case count <ник> &7| "
                    + "&e/case history <ник> &7| &e/case setblock &7| &e/case removeblock &7| "
                    + "&e/case list &7| &e/case reload"));
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "give" -> {
                if (args.length < 3) {
                    sender.sendMessage(txt("&cИспользование: /case give <ник> <кейс> [число]"));
                    return true;
                }
                OfflinePlayer target = findPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage(txt("&cИгрок не найден."));
                    return true;
                }
                Crate c = crates.get(args[2].toLowerCase());
                if (c == null) {
                    sender.sendMessage(txt("&cТакого кейса нет. Список: /case list"));
                    return true;
                }
                int n = 1;
                if (args.length > 3) {
                    try {
                        n = Integer.parseInt(args[3]);
                    } catch (NumberFormatException e) {
                        sender.sendMessage(txt("&cЧисло указано неверно."));
                        return true;
                    }
                }
                if (n <= 0) {
                    sender.sendMessage(txt("&cЧисло должно быть больше нуля."));
                    return true;
                }
                addCount(target.getUniqueId(), c.id, n);
                String tn = target.getName() != null ? target.getName() : args[1];
                sender.sendMessage(txt("&aВыдано: " + c.name + " x" + n + " &aигроку " + tn));
                Player online = target.getPlayer();
                if (online != null) {
                    online.sendMessage(txt("&aВы получили кейс: &f" + c.name + " &ax" + n));
                }
            }
            case "count" -> {
                if (args.length < 2) {
                    sender.sendMessage(txt("&cИспользование: /case count <ник>"));
                    return true;
                }
                OfflinePlayer target = findPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage(txt("&cИгрок не найден."));
                    return true;
                }
                sender.sendMessage(txt("&eКейсы игрока " + args[1] + ":"));
                for (Crate c : crates.values()) {
                    sender.sendMessage(txt("&7- " + c.id + ": &f" + getCount(target.getUniqueId(), c.id)));
                }
            }
            case "history" -> {
                if (args.length < 2) {
                    sender.sendMessage(txt("&cИспользование: /case history <ник>"));
                    return true;
                }
                OfflinePlayer target = findPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage(txt("&cИгрок не найден."));
                    return true;
                }
                List<String> list = data.getStringList("history." + target.getUniqueId());
                sender.sendMessage(txt("&eИстория открытий " + args[1] + " &7(последние 10):"));
                if (list.isEmpty()) {
                    sender.sendMessage(txt("&7- пусто"));
                }
                int shown = 0;
                for (String raw : list) {
                    if (shown >= 10) {
                        break;
                    }
                    String[] e = parseEntry(raw);
                    if (e == null) {
                        continue;
                    }
                    try {
                        Crate c = crates.get(e[1]);
                        sender.sendMessage(txt("&7" + fmtTime(Long.parseLong(e[0])) + " &8| &f"
                                + (c != null ? c.name : e[1]) + " &8→ &f" + e[2]));
                        shown++;
                    } catch (NumberFormatException ex) {
                        // битая запись — пропускаем
                    }
                }
            }
            case "setblock" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage(txt("&cТолько для игрока."));
                    return true;
                }
                Block b = p.getTargetBlockExact(6);
                if (b == null || b.getType().isAir()) {
                    sender.sendMessage(txt("&cПосмотрите на блок (до 6 блоков)."));
                    return true;
                }
                menuBlocks.add(key(b));
                saveBlocks();
                refreshAllHolograms();
                sender.sendMessage(txt("&aБлок привязан: правый клик откроет меню кейсов."));
            }
            case "removeblock" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage(txt("&cТолько для игрока."));
                    return true;
                }
                Block b = p.getTargetBlockExact(6);
                if (b == null || !menuBlocks.contains(key(b))) {
                    sender.sendMessage(txt("&cЭто не блок кейсов."));
                    return true;
                }
                menuBlocks.remove(key(b));
                saveBlocks();
                refreshAllHolograms();
                sender.sendMessage(txt("&aБлок отвязан."));
            }
            case "list" -> sender.sendMessage(txt("&eКейсы: &f" + String.join(", ", crates.keySet())));
            case "reload" -> {
                reloadConfig();
                loadCrates();
                removeAllHolos();
                refreshAllHolograms();
                sender.sendMessage(txt("&aКонфиг перезагружен. Кейсов: " + crates.size()));
            }
            default -> sender.sendMessage(txt("&cНеизвестная подкоманда."));
        }
        return true;
    }

    private OfflinePlayer findPlayer(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            return online;
        }
        OfflinePlayer off = Bukkit.getOfflinePlayer(name);
        if (off.isOnline() || off.hasPlayedBefore()) {
            return off;
        }
        return null;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("hexacase.admin")) {
            return List.of();
        }
        if (args.length == 1) {
            return filter(List.of("give", "count", "history", "setblock", "removeblock", "list", "reload"), args[0]);
        }
        String sub = args[0].toLowerCase();
        if (args.length == 2 && (sub.equals("give") || sub.equals("count") || sub.equals("history"))) {
            List<String> names = new ArrayList<>();
            for (Player p : Bukkit.getOnlinePlayers()) {
                names.add(p.getName());
            }
            return filter(names, args[1]);
        }
        if (args.length == 3 && sub.equals("give")) {
            return filter(new ArrayList<>(crates.keySet()), args[2]);
        }
        return List.of();
    }

    private List<String> filter(List<String> list, String prefix) {
        List<String> out = new ArrayList<>();
        for (String s : list) {
            if (s.toLowerCase().startsWith(prefix.toLowerCase())) {
                out.add(s);
            }
        }
        return out;
    }
}
